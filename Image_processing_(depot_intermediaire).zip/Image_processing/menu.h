// Fichier .h : Gestion des 2 menus
// Auteure : Flavie BREMAND


#ifndef MENU_H
#define MENU_H

int menu();
int menu_3();

#endif //MENU_H
